import { lstatSync, unlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { reportEvent } from './events.js';
import { DEFAULT_EXECUTOR_EFFORT, DEFAULT_EXECUTOR_MODEL } from './executor.js';
import { DEFAULT_VERIFIER_MODEL } from './verifier.js';
import { DEFAULT_ARBITER_MODEL } from './arbiter.js';
import { addUsage, EMPTY_USAGE } from './usage.js';
import { encodeRecordedText, decodeRecordedText } from './execution-record.js';
import { renderDialogueReport } from './dialogue-report.js';

export function participantsFromMessages(messages, models = {}) {
  const participants = new Map();
  for (const message of messages) {
    const response = message.response ?? message.transport;
    if (message.reused || message.skipped || response?.reused || response?.skipped) continue;
    const provider = message.provider ?? message.speaker;
    if (!['claude', 'codex'].includes(provider)) continue;
    const { phase, role } = message;
    const key = `${provider}/${phase}/${role}`;
    const entry = participants.get(key) ?? { provider, phase, role, model: models[provider] ?? null,
      attempted: 0, observed: 0, usageReported: 0, usage: null };
    entry.attempted += response?.attempts?.length || 1;
    if (message.content || response?.stdout) entry.observed++;
    if (response?.usage != null) {
      entry.usageReported++;
      entry.usage = addUsage(entry.usage, response.usage);
    }
    participants.set(key, entry);
  }
  return [...participants.values()];
}

export function recordedMessage(message) {
  return { ...message, provider: message.provider ?? message.speaker,
    recordedContent: message.recordedContent ?? encodeRecordedText(message.content ?? '') };
}

function messageText(message) {
  const decoded = message.recordedContent ? decodeRecordedText(message.recordedContent) : { text: message.content ?? '' };
  return decoded.text + (decoded.truncated
    ? typeof message.content === 'string'
      ? '\n\n[This view was truncated. Inspect the original message content field in uro-runfacts.json for the complete retained message.]'
      : '\n\n[This historical record was truncated; the original complete content was not retained in this record.]' : '');
}

export function buildRunFacts({
  runId,
  physicalRunId,
  target,
  targetPath,
  dir,
  isRepo,
  baseRef = 'HEAD',
  baseCommit = null,
  branch,
  iterations,
  evidence = [],
  tokens = {},
  usageConsistency = null,
  models = {},
  outcome,
  noOpReason,
  gateRetries,
  timeouts = {},
  timeoutEvents = [],
  supervision = null,
  campaignId,
  round,
  unitId,
  campaignUnitKind,
  perspective,
  unitKind,
  merge,
  mutation,
  debate = null,
  skills = null,
  superpowers = null,
  phase, interactionMode, approved, converged, approval = null, authority,
  messages, planningMessages = [], dissent = [], dialogue, resources, reason, nextAction,
  checkpointState, queueResult,
}) {
  const facts = {
    runId,
    ...(physicalRunId === undefined ? {} : { physicalRunId }),
    target,
    ...(targetPath === undefined ? {} : { targetPath }),
    dir, isRepo, baseRef, baseCommit, branch,
    model: {
      executor: models?.executor ?? DEFAULT_EXECUTOR_MODEL,
      executorEffort: models?.executorEffort ?? DEFAULT_EXECUTOR_EFFORT,
      verifier: models?.verifier ?? DEFAULT_VERIFIER_MODEL,
      arbiter: models?.arbiter ?? DEFAULT_ARBITER_MODEL,
    },
    skills: skills ?? null,
    superpowers: superpowers ?? null,
    limits: {
      gateRetries,
      timeoutsMs: {
        executor: timeouts.executor ?? null,
        verifier: timeouts.verifier ?? null,
        arbiter: timeouts.arbiter ?? timeouts.verifier ?? null,
        gate: timeouts.gate ?? null,
      },
    },
    timeoutEvents: Array.isArray(timeoutEvents) ? timeoutEvents : [],
    iterations,
    evidence,
    tokens: {
      executor: addUsage(EMPTY_USAGE, tokens?.executor),
      verifier: addUsage(EMPTY_USAGE, tokens?.verifier),
      arbiter: addUsage(EMPTY_USAGE, tokens?.arbiter),
      total: addUsage(EMPTY_USAGE, tokens?.total),
    },
    usageConsistency: usageConsistency ?? null,
    debate: debate ?? {
      roundsRun: 0,
      maxRounds: null,
      findingsPerRound: [],
      roundHistory: [],
      allFindingIds: [],
      recurredFindingIds: [],
      resolvedFindingIds: [],
      stuckFindingIds: [],
      circlingDetected: false,
      pivotCount: 0,
      finalPivotDecision: null,
      stopReason: 'not-started',
      ledger: {
        rounds: [], allFindingIds: [], recurredFindingIds: [],
        resolvedFindingIds: [], stuckFindingIds: [],
      },
    },
    outcome,
  };
  if (campaignId !== undefined) {
    facts.campaignId = campaignId;
    facts.round = round;
    facts.unitId = unitId;
    facts.campaignUnitKind = campaignUnitKind;
    if (perspective !== undefined) facts.perspective = perspective;
  }
  if (phase !== undefined) {
    Object.assign(facts, { phase, interactionMode, approved, converged, approval, authority,
      messages: (messages ?? []).map(recordedMessage), planningMessages: planningMessages.map(recordedMessage),
      dissent: dissent.map(recordedMessage) });
    facts.participants = participantsFromMessages([...planningMessages, ...(messages ?? [])], {
      claude: models.claude ?? models.arbiter ?? DEFAULT_ARBITER_MODEL,
      codex: models.codex ?? models.executor ?? DEFAULT_EXECUTOR_MODEL,
    });
    facts.participation = Object.fromEntries([...new Set(facts.participants.map(p => p.provider))].map(provider => {
      const entries = facts.participants.filter(p => p.provider === provider);
      return [provider, { attempted: entries.reduce((n, p) => n + p.attempted, 0),
        observed: entries.reduce((n, p) => n + p.observed, 0), usageReported: entries.reduce((n, p) => n + p.usageReported, 0),
        roles: [...new Set(entries.map(p => p.role))] }];
    }));
    // Old records retain legacy buckets. New records expose only actual roles.
    facts.tokens = { total: addUsage(EMPTY_USAGE, tokens.total), participants: facts.participants
      .filter(p => p.usage !== null).map(({ provider, phase, role, usage }) => ({ provider, phase, role, usage })) };
  }
  if (dialogue !== undefined) facts.dialogue = dialogue;
  if (resources !== undefined) facts.resources = resources;
  if (reason !== undefined) facts.reason = reason;
  if (nextAction !== undefined) facts.nextAction = nextAction;
  if (checkpointState !== undefined) facts.checkpointState = checkpointState;
  if (queueResult !== undefined) facts.queueResult = queueResult;
  if (unitKind !== undefined) facts.unitKind = unitKind;
  if (merge !== undefined) facts.merge = merge;
  if (mutation !== undefined) facts.mutation = mutation;
  if (noOpReason !== undefined) facts.noOpReason = noOpReason;
  if (supervision !== null) {
    facts.limits.stall = {
      thresholdMs: supervision.thresholdMs,
      progressThresholdMs: supervision.progressThresholdMs,
      policy: supervision.policy,
      restartLimit: supervision.restartLimit,
    };
    facts.retryCounts = {
      stall: supervision.restartCount,
    };
    facts.stallEvents = Array.isArray(supervision.stallEvents) ? supervision.stallEvents : [];
    facts.livenessChecks = Array.isArray(supervision.livenessChecks)
      ? supervision.livenessChecks
      : [];
  }
  return facts;
}

function formatUsage(usage) {
  const normalized = addUsage(EMPTY_USAGE, usage);
  return `input: ${normalized.inputTokens}; cached input: ${normalized.cachedInputTokens}; `
    + `output: ${normalized.outputTokens}; reasoning output: ${normalized.reasoningOutputTokens}; `
    + `cache write: ${normalized.cacheWriteTokens}`;
}

function tokenTableRow(label, usage) {
  const normalized = addUsage(EMPTY_USAGE, usage);
  return `| ${label} | ${normalized.inputTokens} | ${normalized.cachedInputTokens} `
    + `| ${normalized.outputTokens} | ${normalized.reasoningOutputTokens} `
    + `| ${normalized.cacheWriteTokens} |`;
}

function tokenLines(facts, style) {
  if (Array.isArray(facts.participants)) {
    const rows = facts.participants.filter(p => p.usage !== null);
    return style === 'table' ? [
      '| Provider / phase / role | Input | Cached input | Output | Reasoning output | Cache write |',
      '| --- | ---: | ---: | ---: | ---: | ---: |',
      ...rows.map(p => tokenTableRow(`${p.provider} / ${p.phase} / ${p.role}`, p.usage)),
      tokenTableRow('Total', facts.tokens?.total),
    ] : [...rows.map(p => `- **${p.provider} / ${p.phase} / ${p.role}:** ${formatUsage(p.usage)}`),
      `- **Total:** ${formatUsage(facts.tokens?.total)}`];
  }
  if (style === 'table') {
    return [
      '| Seat | Input | Cached input | Output | Reasoning output | Cache write |',
      '| --- | ---: | ---: | ---: | ---: | ---: |',
      tokenTableRow('Executor', facts.tokens?.executor),
      tokenTableRow('Verifier', facts.tokens?.verifier),
      tokenTableRow('Arbiter', facts.tokens?.arbiter),
      tokenTableRow('Total', facts.tokens?.total),
    ];
  }
  return [
    `- **Executor:** ${formatUsage(facts.tokens?.executor)}`,
    `- **Verifier:** ${formatUsage(facts.tokens?.verifier)}`,
    `- **Arbiter:** ${formatUsage(facts.tokens?.arbiter)}`,
    `- **Total:** ${formatUsage(facts.tokens?.total)}`,
  ];
}

export function buildReportMarkdown(facts, {
  changedFiles = facts.iterations.at(-1)?.changedFiles ?? [],
  formatChangedFile = (file) => file,
  tokenStyle = 'list',
} = {}) {
  const last = facts.iterations.at(-1) ?? {};
  const configuredTimeouts = facts.limits?.timeoutsMs;
  const usageDisagreements = (facts.usageConsistency?.checks ?? [])
    .filter((check) => check.status === 'disagreement');
  const assumedDecision = facts.assumedDecision
    ?? (facts.decision?.escalation === 'operator-absent' ? facts.decision : null);
  const presence = assumedDecision?.presenceEvidence ?? {};
  const unverifiedSuperpowersSeats = Object.entries(facts.superpowers?.seats ?? {})
    .filter(([, seat]) => seat?.verified !== true);
  const md = [
    `# CCC run ${facts.runId}`,
    ``,
    ...(facts.superpowers?.bypassed
      ? [
          `## Superpowers prerequisite bypassed`,
          ``,
          ...(unverifiedSuperpowersSeats.length > 0
            ? [`This run started with \`URO_REQUIRE_SUPERPOWERS=0\`; results were produced without all required seat skills being verified.`]
            : [`This run started with \`URO_REQUIRE_SUPERPOWERS=0\`; the bypass was requested even though all required seat skills were verified.`]),
          ...unverifiedSuperpowersSeats
            .map(([name, seat]) => `- **${name[0].toUpperCase()}${name.slice(1)}:** not verified — ${seat?.evidence ?? 'no evidence recorded'}`),
          ``,
        ]
      : []),
    ...(assumedDecision
      ? [
          `## Decision made while the operator was absent`,
          ``,
          `This was decided without you. The harness concluded you were away before `
            + `continuing inside the isolated worktree.`,
          `- **Presence evidence:** TTY attached: ${presence.ttyAttached ? 'yes' : 'no'}; `
            + `invocation: ${presence.invocation ?? 'unknown'}; operator wait: `
            + `${presence.operatorWait ?? 'unknown'}`,
          `- **Reasoning:** ${assumedDecision.reasoning}`,
          `- **Answers:** ${(assumedDecision.answers ?? [])
            .map((answer) => `${answer.id}: ${answer.answer}`).join('; ') || '(none)'}`,
          ``,
        ]
      : []),
    `- **Outcome:** ${facts.outcome}`,
    ...(facts.noOpReason === undefined ? [] : [`- **No-op reason:** ${facts.noOpReason}`]),
    `- **Evidence:** ${(facts.evidence ?? []).length} command run(s); non-zero exits: ${(facts.evidence ?? []).filter((entry) => entry.code !== 0).length}`,
    `- **Token accounting consistency:** ${facts.usageConsistency?.status ?? 'n/a'}`,
    `- **Base ref:** ${facts.baseRef}`,
    `- **Base commit:** ${facts.baseCommit}`,
    `- **Branch:** ${facts.branch}`,
    ...(facts.perspective === undefined ? [] : [`- **Perspective:** ${facts.perspective}`]),
    `- **Iterations:** ${facts.iterations.length}`,
    `- **Debate rounds:** ${facts.debate?.roundsRun ?? 0}`,
    `- **Debate stopped:** ${facts.debate?.stopReason ?? 'not-recorded'}`,
    ...(facts.reviewProtection?.reviewerRestorations?.length > 0
      ? [`- **Reviewer scope violations restored:** ${facts.reviewProtection.reviewerRestorations
          .flatMap((entry) => entry.paths).join(', ')}`]
      : []),
    ...(facts.reviewProtection?.executorRestorations?.length > 0
      ? [`- **Executor changes to review files restored:** ${facts.reviewProtection.executorRestorations
          .flatMap((entry) => entry.paths).join(', ')}`]
      : []),
    ...(facts.debate?.circlingDetected ? [`- **Debate circling detected:** yes`] : []),
    ...(facts.debate?.finalPivotDecision
      ? [`- **Final pivot decision:** ${facts.debate.finalPivotDecision}`]
      : []),
    ...(facts.unitKind === 'merge'
      ? [
          `- **Unit kind:** merge`,
          `- **Parent order:** ${(facts.merge?.parentOrder ?? []).join(' -> ')}`,
          `- **Merge base:** ${facts.merge?.mergeBase ?? 'n/a'}`,
        ]
      : []),
    ...(facts.mutation
      ? [
          `- **Mutation units examined:** ${facts.mutation.summary?.unitsExamined ?? 0}`,
          `- **Mutation survivors:** ${facts.mutation.summary?.survivors ?? 0}`,
          `- **Mutation unexamined:** ${facts.mutation.summary?.unexamined ?? 0}`,
        ]
      : []),
    ...(configuredTimeouts && Object.values(configuredTimeouts).some((value) => value !== null)
      ? [`- **Timeouts (ms):** executor ${configuredTimeouts.executor}; verifier ${configuredTimeouts.verifier}; arbiter ${configuredTimeouts.arbiter}; gate ${configuredTimeouts.gate}`]
      : []),
    ...(facts.limits?.stall
      ? [
          `- **Stall policy:** ${facts.limits.stall.policy}; gap ${facts.limits.stall.thresholdMs} ms`,
          `- **Progress notice:** ${facts.limits.stall.progressThresholdMs} ms`,
          `- **Restarts used:** stall ${facts.retryCounts?.stall ?? 0}/${facts.limits.stall.restartLimit}`,
        ]
      : []),
    ...(usageDisagreements.length > 0
      ? [
          ``,
          `Token accounting bookkeeping disagreement: cached input exceeded total input. `
            + usageDisagreements.map((check) => {
              const location = [check.seat, check.pass, check.attempt === undefined
                ? null : `attempt ${check.attempt}`].filter(Boolean).join('/');
              return `${location || 'usage'} recorded input ${check.inputTokens}, `
                + `cached input ${check.cachedInputTokens}`;
            }).join('; ') + `.`,
        ]
      : []),
    ...(facts.noOpReason === 'approval-requested'
      ? [
          ``,
          `The executor requested approval instead of implementing the approved plan. `
            + `For a genuinely blocking question, use \`DECISION.md\`, the supported decision channel.`,
        ]
      : []),
    ``,
    `## What changed`,
    changedFiles.map((file) => `- ${formatChangedFile(file)}`).join('\n') || '- (nothing)',
    ``,
    `## Why / reasoning`,
    last.lastMessage ?? '(no executor message)',
    ``,
    `## Review findings (last round)`,
    (facts.debate?.roundHistory?.at(-1)?.findings ?? [])
      .map((finding) => `- ${finding.id} [${finding.severity}] ${finding.description ?? ''}`.trimEnd())
      .join('\n') || '(none recorded)',
  ];
  const nonZeroEvidence = (facts.evidence ?? []).filter((entry) => entry.code !== 0);
  if (facts.outcome === 'needs-decision') {
    md.push('', '## Resume this manual decision', '',
      `Run \`node bin/loop.js resume --run "${facts.dir}" --decision-file <answers.json>\`.`,
      'Read uro-checkpoint.json for the current runId, artifactDigest and pending question IDs. The saved mode and workspace are retained.',
      ...(facts.checkpoint?.status === 'failed' ? [`Checkpoint persistence failed: ${facts.checkpoint.error}`] : []));
  }
  if (facts.phase !== undefined) {
    if (facts.dialogue) {
      md.push('', '## Coworker dialogue', '', renderDialogueReport(facts));
    } else {
      md.push('', '## Decision', '',
        `Phase: ${facts.phase}; mode: ${facts.interactionMode}; authority: ${facts.authority ?? facts.approval?.decidedBy ?? 'not recorded'}`,
        `Approved: ${facts.approved}; Converged: ${facts.converged === null ? 'not recorded' : facts.converged}`);
      if (facts.approval) md.push(`Decision: ${facts.approval.decidedBy}; basis: ${facts.approval.basis}; digest: ${facts.approval.artifactDigest}`,
        facts.approval.reason);
      md.push('', '## Delivered conversation');
      for (const message of [...(facts.planningMessages ?? []), ...(facts.messages ?? [])]) {
        md.push('', `### ${message.provider ?? message.speaker} / ${message.phase} / ${message.role}`, '',
          ...messageText(message).split('\n').map(line => `> ${line}`));
      }
    }
    if (facts.dissent?.length) {
      md.push('', '## Retained dissent');
      for (const message of facts.dissent) md.push('', `${message.provider ?? message.speaker} / ${message.role}`,
        ...messageText(message).split('\n').map(line => `> ${line}`));
    }
  }
  if (nonZeroEvidence.length > 0) {
    md.push(``, `## Evidence — commands that exited non-zero`);
    for (const entry of nonZeroEvidence) {
      const command = [entry.bin, ...(entry.args ?? [])].join(' ');
      md.push(
        ``,
        ...(entry.harness ? [`- **Harness check:** ${entry.harness}`] : []),
        `- **Command:** ${command}`,
        `- **Exit code:** ${entry.code}${entry.timedOut ? ' (timed out)' : ''}`,
        `- **Full output:** ${entry.outFile} · ${entry.errFile}`,
        ``,
        '```text',
        entry.excerpt ?? '',
        '```',
      );
    }
  }
  if ((facts.timeoutEvents ?? []).length > 0) {
    md.push(``, `## Stage timeouts`);
    for (const event of facts.timeoutEvents) {
      const pass = event.pass ? ` (${event.pass} pass)` : '';
      const attempt = event.attempt ? `, attempt ${event.attempt}` : '';
      const command = event.bin
        ? `, command ${[event.bin, ...(event.args ?? [])].join(' ')}`
        : '';
      const last = event.lastEvent ?? {};
      const evidence = Number.isFinite(event.gapMs)
        ? `; ${event.gapMs} ms silence after ${last.stage ?? 'unknown'}/${last.type ?? 'unknown'}`
          + (event.setting ? `; governed initially by ${event.setting}` : '')
          + (event.judged === false ? '; unjudged fallback' : '')
          + (event.reasoning ? `; reason: ${event.reasoning}` : '')
        : '';
      md.push(`- ${event.stage}${pass}: timed out after ${event.timeoutMs} ms `
        + `(iteration ${event.iteration}${attempt}${command})${evidence}`);
    }
  }
  if ((facts.livenessChecks ?? []).length > 0) {
    md.push(``, `## Liveness judgements`);
    for (const check of facts.livenessChecks) {
      const pass = check.pass ? `/${check.pass}` : '';
      const interval = check.status === 'working'
        ? `; next check in ${check.nextIntervalMs} ms`
        : '';
      const provenance = check.judged === false ? 'unjudged fallback' : 'judged';
      md.push(`- ${check.seat ?? 'seat'}${pass}: ${check.status} (${provenance})${interval}; `
        + `reason: ${check.reasoning}`);
    }
  }
  if ((facts.stallEvents ?? []).length > 0) {
    md.push(``, `## Stalls`);
    for (const event of facts.stallEvents) {
      const last = event.lastEvent ?? {};
      const action = event.action === 'restart'
        ? `restart ${event.restart}`
        : 'reported only';
      md.push(`- ${event.stage}: ${event.gapMs} ms gap after ` +
        `${last.stage ?? 'unknown'}/${last.type ?? 'unknown'}; ${action}`);
    }
  }
  if (facts.unitKind === 'merge') {
    const counts = facts.merge?.testCounts ?? {};
    md.push(
      ``,
      `## Merge test-count floor`,
      `- **Count source:** ${counts.source ?? 'n/a'}`,
      `- **Baseline:** ${counts.baseline ?? 'n/a'}`,
      `- **Parents:** ${(counts.parents ?? [])
        .map((parent) => `${parent.unitId}=${parent.count}`).join(', ') || '(none)'}`,
      `- **Required:** ${counts.required ?? 'n/a'}`,
      `- **Actual:** ${counts.actual ?? 'n/a'}`,
      ``,
      `## Merge conflict resolutions`,
    );
    if ((facts.merge?.resolutions ?? []).length === 0) {
      md.push('- (no conflicting paths)');
    } else {
      for (const resolution of facts.merge.resolutions) {
        md.push(`- **${resolution.path}** (${resolution.parentUnitId}): `
          + `${resolution.chosen} — ${resolution.reason}`);
      }
    }
  }
  if (facts.mutation) {
    md.push(
      ``,
      `## Mutation evidence`,
      `- **Status:** ${facts.mutation.status ?? 'unknown'}`,
      `- **Grouping:** ${facts.mutation.grouping?.method ?? 'not-run'} `
        + `(${facts.mutation.grouping?.judged ? 'judged' : 'unjudged'})`,
    );
    for (const survivor of facts.mutation.survivors ?? []) {
      const locations = (survivor.lines ?? [])
        .map((line) => `${line.path}:${line.line}`).join(', ') || '(unknown lines)';
      const tests = (survivor.tests ?? []).join(', ') || '(none selected)';
      md.push(
        `- **Survivor — ${survivor.name}:** ${locations}; tests: ${tests}; `
          + `arbiter: ${survivor.judgement?.verdict ?? 'unjudged'} — `
          + `${survivor.judgement?.reasoning ?? 'no reasoning recorded'}`,
      );
    }
    for (const unit of facts.mutation.unexamined ?? []) {
      md.push(`- **Unexamined — ${unit.name}:** ${unit.reason ?? 'no reason recorded'}`);
    }
  }
  md.push(
    ``,
    `## Tokens`,
    ...tokenLines(facts, tokenStyle),
    ``,
  );
  return md.join('\n');
}

export function writeReport({ dir, facts, reporter, runId = facts.runId }) {
  const jsonPath = join(dir, 'uro-runfacts.json');
  const mdPath = join(dir, 'uro-report.md');
  reportEvent(reporter, runId, 'report', 'start', {
    files: ['uro-runfacts.json', 'uro-report.md'],
  });
  writeFileSync(jsonPath, JSON.stringify(facts, null, 2));
  const markdown = buildReportMarkdown(facts);
  writeFileSync(mdPath, markdown);
  reportEvent(reporter, runId, 'report', 'finish', {
    file: 'uro-runfacts.json', files: ['uro-runfacts.json', 'uro-report.md'],
  });
  return { jsonPath, mdPath };
}

/** Refresh already-created report files without emitting a second lifecycle event. */
export function refreshReportProjection({ dir, facts }) {
  const jsonPath = join(dir, 'uro-runfacts.json');
  const mdPath = join(dir, 'uro-report.md');
  try {
    for (const [path, label] of [[jsonPath, 'run facts'], [mdPath, 'Markdown report']]) {
      const stat = lstatSync(path);
      if (stat.isSymbolicLink() || !stat.isFile()) {
        if (stat.isSymbolicLink()) unlinkSync(path);
        throw new Error(`${label} refresh target must be an existing regular file`);
      }
    }
    const json = JSON.stringify(facts, null, 2);
    const markdown = buildReportMarkdown(facts);
    writeFileSync(jsonPath, json);
    writeFileSync(mdPath, markdown);
    return { jsonPath, mdPath };
  } catch (error) {
    // A failed final refresh must not leave an older approved Markdown projection visible.
    try {
      const stat = lstatSync(mdPath);
      if (stat.isFile() || stat.isSymbolicLink()) unlinkSync(mdPath);
    } catch { /* absent/non-removable target remains an explicit refresh failure */ }
    throw error;
  }
}
